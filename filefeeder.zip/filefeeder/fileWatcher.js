// Imports / Requires
var fileFetch = require("fs");
var dirwatch = require("./modules/DirectoryWatcher.js");

var MongoClient = require('mongodb').MongoClient;
var assert = require('assert');
var ObjectId = require('mongodb').ObjectID;
var url = 'mongodb://localhost:27017/cfg';


var insertDocument = function(db,fileObj,collectionName,callback) {
   db.collection('Alert_'+collectionName).insertOne( {fileObj}
, function(err, result) {
    assert.equal(err, null);
    console.log("Inserted a document into the alerts collection.");
    callback();
  });
};


// Create a monitor object that will watch a directory

// This has to be changed as per the location of the inbound files//
var simMonitor = new dirwatch.DirectoryWatcher("C:\\Inbound", true);

// start the monitor and have it check for updates
// every half second.

simMonitor.start(500);

// Log to the console when a file is removed

simMonitor.on("fileRemoved", function (filePath) {
  console.log("File Deleted: " + filePath);
});

// Log to the console when a file is changed.
simMonitor.on("fileChanged", function (fileDetail, changes) {
  console.log("File Changed: " + fileDetail.fullPath);
  for (var key in changes) {
    console.log("  + " + key + " changed...");
    console.log("    - From: " + ((changes[key].baseValue instanceof Date) ? 
    changes[key].baseValue.toISOString() : changes[key].baseValue));
    console.log("    - To  : " + ((changes[key].comparedValue instanceof Date) ? 
    changes[key].comparedValue.toISOString() : changes[key].comparedValue));
  }
});

// log to the console when a file is added.

simMonitor.on("fileAdded", function (fileDetail) {
  console.log("File Added: " + fileDetail.fullPath);
  
  fileFetch.readFile(fileDetail.fullPath, 'utf8', function (err, data) {
    if (err) throw err; 
      try{// we'll consider error handling for now
          var fileObj = JSON.parse(data);
          collectionName = fileObj.appname;
          console.log(fileObj);
		  
		  MongoClient.connect(url, function(err, db) {
          assert.equal(null, err);
          insertDocument(db,fileObj,collectionName, function() {
           db.close();
        });
        });
		  
          }catch(fileException){
                         console.log(fileException.message);
       
                 };
				 			 
  });
  fileFetch.unlink(fileDetail.fullPath);
  
});

// Let us know that directory monitoring is happening and where.
console.log("Directory Monitoring of " + simMonitor.root + " has started");