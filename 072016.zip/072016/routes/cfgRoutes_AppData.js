var http = require('http'),
    url  = require('url'),
    express = require('express'),
    router = express.Router(),
    mongoose = require('mongoose'),
    bodyParser = require('body-parser'),
    methodOverride = require('method-override');
	
// Laod Application data Cache on initiation of App
	                         
applicationReferenceModel = "applicationReference" ;
var applicationReferenceObject
mongoose.model(applicationReferenceModel)
.find({}, function (err, referenceAppModel) 
		{
			if(err) {
					console.log("Error : DB connection error while fetching Application Reference data :"+err);
				}
			else {
				console.log(referenceAppModel);
					applicationReferenceObject = referenceAppModel; 
				}
	});


var getAppReferenceData = function (appName){
			
  var result = [];

  applicationReferenceObject.forEach(function(object){if (object.appname == appName) result.push(o);} );

  return result? result[0] : null; // or undefined

}
	

// accessPath :  http://127.0.0.1:3000/

// evaluateAlert method : ARGZ(Set of Alert Objects , Reference App Object)  : Return Evaluated Alert Set

var evaluateAlerts = function(alertObjectSet,referenceObject){
    


    paramInfraRef = Object.keys(referenceObject.paramInfra).sort() ;
    paramCustomRef = Object.keys(referenceObject.paramCustom).sort() ;

alertObjectSet.forEach(function(alertObject){

    
	var paramInfraAlert = Object.keys(alertObject.paramInfra).sort() ;
    	var paramCustomAlert = Object.keys(alertObject.paramCustom).sort() ;
	

	for ( var i = 0 ; i<paramInfraAlert.length ; i++ ){

			switch(toUpperCase(paramInfraAlert[i].paramType)){
			
				case 'CPU' : 
						parseInt(paramInfraAlert[i].value) >= parseInt(paramInfraRef[i].value) ?  paramInfraAlert[i]["flag"] = true : paramInfraAlert[i]["flag"] = false;
						break; 
				case 'DISK':
						parseInt(paramInfraAlert[i].value.slice(0, -1)) >= parseInt(paramInfraRef[i].value.slice(0, -1)) ?  paramInfraAlert[i]["flag"] = true : paramInfraAlert[i]["flag"] = false;
						break;
				case 'SYSTEM':
						paramInfraAlert[i]["flag"] = false;
				                break;
  	
			};		
			
	};
	
	for ( var i = 0 ; i<paramCustomAlert.length ; i++ ){

			switch(toUpperCase(paramCustomAlert[i].paramType)){
			
				case 'LINES' : 
						toUpperCase(paramCustomAlert[i].value) == "UP" ?  paramCustomAlert[i]["flag"] = false : paramCustomAlert[i]["flag"] = true;
						break; 
				case 'FILE_TYPE_COUNT':
						switch(paramCustomRef[i].frequency){
							
								case 'Daily' :  paramCustomAlert[i]["flag"] = false;break;
								case 'Monthly': paramCustomAlert[i]["flag"] = false;break;

							};
						break;
				case 'SCALAR':
						paramCustomAlert[i]["flag"] = false;
				                break;
  	
			};		
			
	};

console.log(paramCustomAlert);
console.log(paramInfraAlert);

});

}

router.route('/getAppData')

//GET data for /getAppData

    .get(function(req, res, next) {
        var url_parts = url.parse(req.url, true),
            query = url_parts.query;

        var collectionName  = "Alert_"+query.appName;
        var metricValue = query.value;
	var metric = query.metric;
	//console.log(JSON.parse(JSON.stringify(queryObject)));
	//console.log(req);
        
	mongoose.model(collectionName).find({ },{skip:0,limit:metricValue,sort:{sequenceId: -1}}, function (err, alerts) {
              if (err) {
                  return console.error(err);
              } else {
		  res.format({
                  //HTML response
		  
                  //JSON response
                  
		  json: function(){
			    //console.log(alerts);
                            var result = evaluateAlerts(getAppReferenceData(appName),alerts);		
	                    res.json(result);
        	            }
                });
              }     
        });
    });

module.exports = router;