var mongoose = require('mongoose');  
mongoose.model('Alert_MTSQA');