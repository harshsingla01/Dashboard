var mongoose = require('mongoose');  
mongoose.model('applicationReference');